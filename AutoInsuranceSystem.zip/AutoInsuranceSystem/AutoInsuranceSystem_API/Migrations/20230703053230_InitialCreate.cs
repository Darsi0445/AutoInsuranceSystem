﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AutoInsuranceSystem_API.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customer_Details",
                columns: table => new
                {
                    CustomerId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNo = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Details", x => x.CustomerId);
                });

            migrationBuilder.CreateTable(
                name: "Login_Details",
                columns: table => new
                {
                    LoginId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Login_Details", x => x.LoginId);
                });

            migrationBuilder.CreateTable(
                name: "Master_Table",
                columns: table => new
                {
                    MasterId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Year = table.Column<int>(type: "int", nullable: false),
                    Make = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Model = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cost = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Master_Table", x => x.MasterId);
                });

            migrationBuilder.CreateTable(
                name: "Policies",
                columns: table => new
                {
                    PolicyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomersCustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Policies", x => x.PolicyId);
                    table.ForeignKey(
                        name: "FK_Policies_Customer_Details_CustomersCustomerId",
                        column: x => x.CustomersCustomerId,
                        principalTable: "Customer_Details",
                        principalColumn: "CustomerId");
                });

            migrationBuilder.CreateTable(
                name: "Vehicle_Details",
                columns: table => new
                {
                    VehicleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: true),
                    Make = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Model = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Year = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    AntiTheft = table.Column<bool>(type: "bit", nullable: false),
                    CustomersCustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicle_Details", x => x.VehicleId);
                    table.ForeignKey(
                        name: "FK_Vehicle_Details_Customer_Details_CustomersCustomerId",
                        column: x => x.CustomersCustomerId,
                        principalTable: "Customer_Details",
                        principalColumn: "CustomerId");
                });

            migrationBuilder.CreateTable(
                name: "BreakUp_Details",
                columns: table => new
                {
                    BreakUpId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VehicleId = table.Column<int>(type: "int", nullable: true),
                    DepreciatedValue = table.Column<float>(type: "real", nullable: false),
                    DeclaredValue = table.Column<float>(type: "real", nullable: false),
                    Electrical = table.Column<float>(type: "real", nullable: false),
                    NonElectrical = table.Column<float>(type: "real", nullable: false),
                    DuelFuelFit = table.Column<float>(type: "real", nullable: false),
                    SubTotal = table.Column<float>(type: "real", nullable: false),
                    AntiTheft = table.Column<float>(type: "real", nullable: false),
                    Bonus = table.Column<float>(type: "real", nullable: false),
                    Vehicle_DetailsVehicleId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BreakUp_Details", x => x.BreakUpId);
                    table.ForeignKey(
                        name: "FK_BreakUp_Details_Vehicle_Details_Vehicle_DetailsVehicleId",
                        column: x => x.Vehicle_DetailsVehicleId,
                        principalTable: "Vehicle_Details",
                        principalColumn: "VehicleId");
                });

            migrationBuilder.CreateTable(
                name: "Claim_Details",
                columns: table => new
                {
                    ClaimId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VehicleId = table.Column<int>(type: "int", nullable: true),
                    Cause = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PolicyNumber = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Amount = table.Column<int>(type: "int", nullable: false),
                    Vehicle_DetailsVehicleId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Claim_Details", x => x.ClaimId);
                    table.ForeignKey(
                        name: "FK_Claim_Details_Vehicle_Details_Vehicle_DetailsVehicleId",
                        column: x => x.Vehicle_DetailsVehicleId,
                        principalTable: "Vehicle_Details",
                        principalColumn: "VehicleId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_BreakUp_Details_Vehicle_DetailsVehicleId",
                table: "BreakUp_Details",
                column: "Vehicle_DetailsVehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_Claim_Details_Vehicle_DetailsVehicleId",
                table: "Claim_Details",
                column: "Vehicle_DetailsVehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_Policies_CustomersCustomerId",
                table: "Policies",
                column: "CustomersCustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Vehicle_Details_CustomersCustomerId",
                table: "Vehicle_Details",
                column: "CustomersCustomerId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BreakUp_Details");

            migrationBuilder.DropTable(
                name: "Claim_Details");

            migrationBuilder.DropTable(
                name: "Login_Details");

            migrationBuilder.DropTable(
                name: "Master_Table");

            migrationBuilder.DropTable(
                name: "Policies");

            migrationBuilder.DropTable(
                name: "Vehicle_Details");

            migrationBuilder.DropTable(
                name: "Customer_Details");
        }
    }
}
