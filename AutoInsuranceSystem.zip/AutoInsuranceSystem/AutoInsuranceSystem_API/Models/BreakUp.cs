﻿using AutoInsuranceSystem_API.Models;
using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace Insurance_API.Models

{

    [Table("BreakUp_Details")]

    public class BreakUp

    {

        [Key]

        public int BreakUpId { get; set; }

        public int? VehicleId { get; set; }

        public float DepreciatedValue { get; set; }

        public float DeclaredValue { get; set; }

        public float Electrical { get; set; }

        public float NonElectrical { get; set; }

        public float DuelFuelFit { get; set; }

        public float SubTotal { get; set; }

        public float AntiTheft { get; set; }

        public float Bonus { get; set; }

        public virtual Vehicle_Details? Vehicle_Details { get; set; }

    }

}