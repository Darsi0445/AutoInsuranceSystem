﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsuranceSystem_API.Models

{

    [Table("Claim_Details")]

    public class Claim

    {

        [Key]

        public int ClaimId { get; set; }

        public int? VehicleId { get; set; }

        public string Cause { get; set; }=String.Empty;

        public int PolicyNumber { get; set; }

        public DateTime Date { get; set; }

        public int Amount { get; set; }

        public virtual Vehicle_Details? Vehicle_Details { get; set; }

    }

}

