﻿using AutoInsuranceSystem_API.Models;
using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsuranceSystem_API.Models

{

    [Table("Vehicle_Details")]

    public class Vehicle_Details

    {

        [Key]

        public int VehicleId { get; set; }

        public string? CustomerId { get; set; }

        public string Make { get; set; } = String.Empty;

        public string Model { get; set; } = String.Empty;

        public int Year { get; set; }

        public int Price { get; set; }

        public bool AntiTheft { get; set; }

        public virtual Customers? Customers { get; set; }

    }

}