﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsuranceSystem_API.Models

{

    [Table("Login_Details")]

    public class Login

    {

        [Key]

        public int LoginId { get; set; }

        public string Email { get; set; }=String.Empty;

        public string Password { get; set; } = String.Empty;

    }

}