﻿using AutoInsuranceSystem_API.Models;
using System.ComponentModel.DataAnnotations;

namespace Insurance_API.Models

{

    public class Policy

    {

        [Key]

        public int PolicyId { get; set; }

        public string? CustomerId { get; set; }

        public virtual Customers? Customers { get; set; }

    }

}