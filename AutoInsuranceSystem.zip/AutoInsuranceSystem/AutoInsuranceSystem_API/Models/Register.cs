﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace Insurance_API.Models

{

    public class Register

    {

        public string Email { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Address { get; set; }

        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Password doesnot match")]

        public string ConfirmPassword { get; set; }

        public long PhoneNo { get; set; }

    }

}