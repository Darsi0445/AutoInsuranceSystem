﻿
using AutoInsuranceSystem_API.Models;
using Insurance_API.Models;
using Microsoft.EntityFrameworkCore;

namespace AutoInsuranceSystem_API.Models

{

    public class InsuranceDBContext : DbContext

    {

        public InsuranceDBContext(DbContextOptions options) : base(options)

        {

        }

        public virtual DbSet<Customers> Customers { get; set; }

        public virtual DbSet<BreakUp> BreakUps { get; set; }
        public virtual DbSet<Policy> Policies { get; set; }

        public virtual DbSet<Claim> Claim { get; set; }

        public virtual DbSet<MasterTable> MasterTables { get; set; }

        public virtual DbSet<Vehicle_Details> Vehicle_Details { get; set; }

        public virtual DbSet<Login> Logins { get; set; }
        public virtual DbSet<RejectedClaims> RejectedClaims { get; set; }
        public virtual DbSet<ApprovedClaims> ApprovedClaims { get; set; }


    }

}

