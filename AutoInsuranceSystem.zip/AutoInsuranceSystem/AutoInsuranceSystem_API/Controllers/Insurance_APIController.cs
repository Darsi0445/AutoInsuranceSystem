﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;

using Insurance_API.Models;
using AutoInsuranceSystem_API.Models;

namespace Insurance_API.Controllers

{

    [ApiController]

    [Route("api/[controller]")]

    public class InsuranceController : Controller

    {

        InsuranceDBContext db = null;

        public InsuranceController(InsuranceDBContext db)

        {

            this.db = db;

        }

        [HttpPost]

        [Route("Register")]

        public IActionResult Register([FromBody] Register r)

        {

            if (r == null)

            {

                return BadRequest();

            }

            else

            {

                Customers c = new Customers();

                c.FirstName = r.FirstName;

                c.LastName = r.LastName;

                c.CustomerId = r.Email;

                c.Address = r.Address;

                c.PhoneNo = r.PhoneNo;

                c.Password = r.Password;

                db.Customers.Add(c);

                db.SaveChanges();

                return Ok(c);

            }

        }

        [HttpPost]

        [Route("customerlogin")]

        public IActionResult Login([FromBody] Login l)

        {

            if (l == null)

            {

                return BadRequest();

            }

            var customer = (from c in db.Customers

                            where c.CustomerId == l.Email && c.Password == l.Password

                            select c).SingleOrDefault();

            if (customer == null)

            {

                return BadRequest();

            }

            else

            {

                // l.CustomerId = customer.CustomerId;

                l.Email = customer.CustomerId;

                l.Password = customer.Password;

                db.Logins.Add(l);

                db.SaveChanges();

                return Ok();

            }

        }

        [HttpGet]

        [Route("getmake")]

        public IActionResult Make(int year)

        {

            var make = from m in db.MasterTables

                       where m.Year == year

                       select m;

            return Ok(make.ToList());

        }

        [HttpGet]

        [Route("getmodel")]

        public IActionResult Model(int year, string make)

        {

            var model = from m in db.MasterTables

                        where m.Year == year && m.Make == make

                        select m;

            return Ok(model.ToList());

        }

        [HttpPost]

        [Route("addvehicle")]

        public IActionResult AddVeh([FromBody] Vehicle_Details v)

        {

            if (v == null)

            {

                return BadRequest();

            }

            else

            {

                db.Vehicle_Details.Add(v);

                db.SaveChanges();

                return Ok();

            }

        }

        [HttpGet]

        [Route("vehicle")]

        public IActionResult Vehicle()

        {

            var vehicle = (from v in db.Vehicle_Details

                           orderby v.VehicleId

                           select v).LastOrDefault();

            return Ok(vehicle);

        }

        [HttpGet]

        [Route("breakup/{id}")]

        public IActionResult Breakup(int id)

        {

            BreakUp b = new BreakUp();

            b.VehicleId = id;

            var veh = (from v in db.Vehicle_Details

                       where v.VehicleId == id

                       select v).SingleOrDefault();

            var gap = DateTime.Now.Year - veh.Year;

            if (gap <= 5)

            {

                b.DepreciatedValue = (float)10 * veh.Price * gap / 100;

            }

            else

            {

                b.DepreciatedValue = (float)5 * veh.Price * gap / 100;

            }

            b.DeclaredValue = (float)3 * b.DepreciatedValue / 100;

            b.Electrical = (float)25 * b.DeclaredValue / 100;

            b.NonElectrical = (float)15 * b.DeclaredValue / 100;

            b.DuelFuelFit = (float)30 * b.DeclaredValue / 100;

            b.SubTotal = b.DeclaredValue + b.Electrical + b.NonElectrical + b.DuelFuelFit;

            b.AntiTheft = (float)5 * b.SubTotal / 100;

            b.Bonus = (float)20 * b.SubTotal / 100;

            db.BreakUps.Add(b);

            db.SaveChanges();

            return Ok(b);

        }

        [HttpGet]

        [Route("addpolicy/{id}")]

        public IActionResult AddPolicy(string id)

        {

            Policy p = new Policy();

            p.CustomerId = id;

            db.Policies.Add(p);

            db.SaveChanges();

            return Ok(p);

        }

        [HttpPost]

        [Route("makeclaim")]

        public IActionResult Claim([FromBody] Claim c)

        {

            if (c == null)

            {

                return BadRequest();

            }

            else

            {

                if (ModelState.IsValid)

                {

                    db.Claim.Add(c);

                    db.SaveChanges();

                    return Ok();

                }

                return BadRequest();

            }

        }

    }

}

