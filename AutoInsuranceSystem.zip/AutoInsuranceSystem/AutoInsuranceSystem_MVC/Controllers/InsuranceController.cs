﻿using AutoInsuranceSystem_MVC.Models;

using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;

using System.Text;

using System.Diagnostics;
using Microsoft.Win32;

namespace AutoInsuranceSystem_MVC.Controllers

{

    public class InsuranceController : Controller

    {

        private readonly ILogger<InsuranceController> _logger;

        public InsuranceController(ILogger<InsuranceController> logger)

        {

            _logger = logger;

        }

        public IActionResult Index()

        {

            return View();

        }

        public IActionResult Login()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> Login(LoginViewModel l)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(l), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("http://localhost:44917/api/Insurance/customerlogin", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                HttpContext.Session.SetString("Email", l.Email);

                                //HttpContext.Session.SetInt32("UserId", l.CustomerId);

                                return RedirectToAction("Quote");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult Register()

        {

            return View();

        }
        [HttpPost]

        public async Task<IActionResult> Register(RegisterViewModel r)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(r), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("http://localhost:44917/api/Insurance/Register", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                return RedirectToAction("Login");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult Logout()

        {

            HttpContext.Session.Clear();

            return RedirectToAction("Index");

        }

        public IActionResult Quote()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> Quote(VehicleDetails v)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(v), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("http://localhost:44917/api/Insurance/addvehicle", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                return RedirectToAction("Break");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public async Task<IActionResult> Break()

        {

            try

            {

                VehicleDetails v = null;

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("http://localhost:44917/api/Insurance/vehicle"))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        v = JsonConvert.DeserializeObject<VehicleDetails>(apiResponse);

                    }

                }

                HttpContext.Session.SetInt32("VehicleId", v.VehicleId);

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public async Task<IActionResult> Premium(int id)

        {

            try

            {

                BreakUp b = null;

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("http://localhost:44917/api/Insurance/breakup/" + id))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        b = JsonConvert.DeserializeObject<BreakUp>(apiResponse);

                    }

                }

                return View(b);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public async Task<IActionResult> Policy(string id)

        {

            try

            {

                Policy p = null;

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("http://localhost:44917/api/Insurance/addpolicy/" + id))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        p = JsonConvert.DeserializeObject<Policy>(apiResponse);

                    }

                }

                return View(p);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult Claim()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> Claim(Claim c)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(c), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("http://localhost:44917/api/Insurance/makeclaim", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                return RedirectToAction("success");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult success()

        {

            return View();

        }

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]

        //public IActionResult Error()

        //{

        // return View(new ErrorViewModel

        // {

        // RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier

        // });

        //}

    }

}



