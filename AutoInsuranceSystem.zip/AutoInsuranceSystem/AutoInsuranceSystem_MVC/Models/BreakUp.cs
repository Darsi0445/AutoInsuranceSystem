﻿
using System.ComponentModel.DataAnnotations;


namespace AutoInsuranceSystem_MVC.Models
{
    public class BreakUp
    {
        public int BreakUpId { get; set; }

        public int? VehicleId { get; set; }

        [Required]

        public float DepreciatedValue { get; set; }

        [Required]

        public float DeclaredValue { get; set; }

        [Required]

        public float Electrical { get; set; }

        [Required]

        public float NonElectrical { get; set; }

        [Required]

        public float DuelFuelFit { get; set; }

        [Required]

        public float SubTotal { get; set; }

        [Required]

        public float AntiTheft { get; set; }

        [Required]

        public float Bonus { get; set; }

    }

}
    

