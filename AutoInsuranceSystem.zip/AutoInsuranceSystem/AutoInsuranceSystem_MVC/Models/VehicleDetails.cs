﻿using System.ComponentModel.DataAnnotations;

namespace AutoInsuranceSystem_MVC.Models
{
    public class VehicleDetails
    {
        public int VehicleId { get; set; }

        [Required]

        public string? EmailId { get; set; }

        [Required]

        public string Make { get; set; }

        [Required]

        public string Model { get; set; }

        [Required]

        public int Year { get; set; }

        [Required]

        public int Price { get; set; }

        [Required]

        public bool AntiTheft { get; set; }
    }
}
