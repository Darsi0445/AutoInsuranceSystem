﻿using System.ComponentModel.DataAnnotations;


namespace AutoInsuranceSystem_MVC.Models
{
    public class RegisterViewModel
    {
        [Required]

        public string Email { get; set; } = string.Empty;

        [Required]

        public string FirstName { get; set; } = string.Empty;

        [Required]

        public string LastName { get; set; } = string.Empty;

        [Required]

        public string Address { get; set; } = string.Empty;

        [Required]

        public string Password { get; set; } = string.Empty;

        [Required]

        [Compare("Password", ErrorMessage = "Password doesnot match")]

        public string ConfirmPassword { get; set; } = string.Empty;

        [Required]

        public long PhoneNo { get; set; }
    }
}
