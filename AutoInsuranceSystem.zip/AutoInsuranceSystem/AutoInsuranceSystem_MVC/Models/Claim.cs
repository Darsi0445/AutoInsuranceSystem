﻿using System.ComponentModel.DataAnnotations;

namespace AutoInsuranceSystem_MVC.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }

        [Required]

        public int? VehicleId { get; set; }

        [Required]

        public string Cause { get; set; }

        [Required]

        public int PolicyNumber { get; set; }

        [Required]

        public DateTime Date { get; set; }

        [Required]

        public int Amount { get; set; }
    }
}
