﻿namespace AutoInsuranceSystem_MVC.Models
{
    public class Policy
    {
        public int PolicyId { get; set; }

        public string? CustomerId { get; set; }
    }
}
